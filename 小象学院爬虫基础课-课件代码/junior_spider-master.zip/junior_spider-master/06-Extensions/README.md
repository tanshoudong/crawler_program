## JSONView
    https://github.com/gildas-lormeau/JSONView-for-Chrome

##POSTMAN
    https://github.com/postmanlabs/postman-app-support/releases

## POSTMAN Intercepter
    https://github.com/postmanlabs/postman-chrome-interceptor/releases


## 离线安装方法
    1. Google Chrome 的浏览器里输入 chrome://extensions
    2. 选择 Load Unpacked
   
## 在线安装方法
在 Chrome 里输入 chrome://extensions，在搜索框里，分别输入 JSONView，POSTMAN 及 POSTMAN Intercepter，点击安装