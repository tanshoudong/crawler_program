headers = {
    'Host': "www.newsmth.net",
    'User-Agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:64.0) Gecko/20100101 Firefox/64.0",
    'Accept': "application/json, text/javascript, */*; q=0.01",
    'Accept-Language': "en-US,en;q=0.5",
    'Accept-Encoding': "gzip, deflate",
    'Referer': "http://www.newsmth.net/nForum/",
    'X-Requested-With': "XMLHttpRequest",
    'Connection': "keep-alive",
    'Cache-Control': "max-age=0",
    'cache-control': "no-cache"
}

crawl_interval = 2.5